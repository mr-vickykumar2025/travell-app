const express = require('express');
const router = express.Router();
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const sendOtp = require('../utils/mailer');

function genOtp() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Request OTP
router.post('/request-otp', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email required' });
  try {
    let user = await User.findOne({ email });
    if (!user) user = await User.create({ email });
    const code = genOtp();
    user.otp = { code, expiresAt: new Date(Date.now() + 10 * 60 * 1000) }; // 10 minutes
    await user.save();
    const info = await sendOtp(email, code);
    return res.json({ ok: true, info });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Verify OTP
router.post('/verify-otp', async (req, res) => {
  const { email, otp } = req.body;
  if (!email || !otp) return res.status(400).json({ error: 'Email & OTP required' });
  try {
    const user = await User.findOne({ email });
    if (!user || !user.otp) return res.status(400).json({ error: 'OTP not requested' });
    if (user.otp.expiresAt < new Date()) return res.status(400).json({ error: 'OTP expired' });
    if (user.otp.code !== otp) return res.status(400).json({ error: 'Invalid OTP' });
    user.otp = null;
    await user.save();
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || 'secret123', { expiresIn: '7d' });
    res.cookie('token', token, { httpOnly: true, sameSite: 'lax' }).json({ ok: true });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
});

router.post('/logout', (req, res) => {
  res.clearCookie('token').json({ ok: true });
});

router.get('/me', async (req, res) => {
  try {
    const token = req.cookies['token'];
    if (!token) return res.json({ user: null });
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'secret123');
    const user = await User.findById(payload.id).select('-otp');
    res.json({ user });
  } catch (err) {
    res.json({ user: null });
  }
});

module.exports = router;
