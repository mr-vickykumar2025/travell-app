const express = require('express');
const router = express.Router();
const Trip = require('../models/Trip');
const auth = require('../middleware/auth');

// Create trip
router.post('/', auth, async (req, res) => {
  try {
    const data = req.body;
    const count = await Trip.countDocuments({ user: req.user._id });
    data.user = req.user._id;
    data.tripNumber = count + 1;
    const trip = await Trip.create(data);
    res.json({ trip });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get trips (history)
router.get('/', auth, async (req, res) => {
  try {
    const trips = await Trip.find({ user: req.user._id }).sort({ createdAt: -1 });
    res.json({ trips });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
