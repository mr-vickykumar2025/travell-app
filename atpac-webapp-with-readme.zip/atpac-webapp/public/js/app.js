// login and OTP UI
const emailStep = document.getElementById('email-step');
const otpStep = document.getElementById('otp-step');
const emailInput = document.getElementById('email');
const otpInput = document.getElementById('otp');
const reqBtn = document.getElementById('request-otp');
const verifyBtn = document.getElementById('verify-otp');
const emailMsg = document.getElementById('email-msg');
const otpMsg = document.getElementById('otp-msg');

reqBtn.addEventListener('click', async () => {
  const email = emailInput.value.trim();
  if (!email) { emailMsg.textContent = 'Please enter your email'; return; }
  emailMsg.textContent = 'Requesting OTP...';
  try {
    const res = await fetch('/api/auth/request-otp', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ email })
    });
    const j = await res.json();
    if (j.ok) {
      emailMsg.textContent = 'OTP sent (check email).';
      emailStep.classList.add('hidden');
      otpStep.classList.remove('hidden');
    } else {
      emailMsg.textContent = j.error || 'Could not send OTP';
    }
  } catch (err) {
    emailMsg.textContent = 'Network error';
  }
});

verifyBtn.addEventListener('click', async () => {
  const email = emailInput.value.trim();
  const otp = otpInput.value.trim();
  if (!otp) { otpMsg.textContent = 'Enter the OTP'; return; }
  otpMsg.textContent = 'Verifying...';
  try {
    const res = await fetch('/api/auth/verify-otp', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ email, otp }),
      credentials: 'include'
    });
    const j = await res.json();
    if (j.ok) {
      otpMsg.textContent = 'Verified! Redirecting...';
      window.location.href = '/dashboard.html';
    } else {
      otpMsg.textContent = j.error || 'Invalid OTP';
    }
  } catch (err) {
    otpMsg.textContent = 'Network error';
  }
});
