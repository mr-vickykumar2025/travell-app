async function api(path, opts = {}) {
  opts.credentials = 'include';
  opts.headers = opts.headers || {};
  if (opts.body && typeof opts.body === 'object') {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(opts.body);
  }
  const res = await fetch(path, opts);
  return res.json();
}

document.getElementById('logout').addEventListener('click', async () => {
  await api('/api/auth/logout', { method: 'POST' });
  window.location.href = '/';
});

// Trip recording
let tripState = null; // {startTime, startCoords}
const startBtn = document.getElementById('start-trip');
const endBtn = document.getElementById('end-trip');
const statusP = document.getElementById('trip-status');
const tripForm = document.getElementById('trip-form');

startBtn.addEventListener('click', async () => {
  if (!navigator.geolocation) { alert('Geolocation not supported'); return; }
  startBtn.disabled = true;
  statusP.textContent = 'Obtaining current location...';
  navigator.geolocation.getCurrentPosition(pos => {
    const coords = pos.coords;
    tripState = { startTime: new Date().toISOString(), origin: { lat: coords.latitude, lng: coords.longitude } };
    statusP.textContent = `Trip started at ${new Date(tripState.startTime).toLocaleString()}`;
    endBtn.disabled = false;
    tripForm.classList.remove('hidden');
  }, err => {
    statusP.textContent = 'Location permission denied or error';
    startBtn.disabled = false;
  }, { enableHighAccuracy: true });
});

endBtn.addEventListener('click', async () => {
  if (!tripState) return;
  statusP.textContent = 'Obtaining destination location...';
  navigator.geolocation.getCurrentPosition(pos => {
    const coords = pos.coords;
    tripState.endTime = new Date().toISOString();
    tripState.destination = { lat: coords.latitude, lng: coords.longitude };
    statusP.textContent = `Trip ended at ${new Date(tripState.endTime).toLocaleString()}`;
    endBtn.disabled = true;
  }, err => {
    statusP.textContent = 'Could not capture destination location';
  }, { enableHighAccuracy: true });
});

tripForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!tripState || !tripState.endTime) return alert('Please start and end the trip first');
  const mode = document.getElementById('mode').value;
  const purpose = document.getElementById('purpose').value;
  const accText = document.getElementById('accompanying').value;
  const accompanying = accText.split(',').map(s => s.trim()).filter(Boolean).map(name => ({ name }));
  const payload = {
    origin: { ...tripState.origin },
    destination: { ...tripState.destination },
    startTime: tripState.startTime,
    endTime: tripState.endTime,
    mode, purpose, accompanying
  };
  const res = await api('/api/trips', { method: 'POST', body: payload });
  if (res.trip) {
    alert('Trip saved');
    // reset UI
    tripState = null;
    tripForm.reset();
    tripForm.classList.add('hidden');
    startBtn.disabled = false;
    endBtn.disabled = true;
    statusP.textContent = 'No trip in progress';
    loadHistory();
  } else {
    alert('Could not save trip');
  }
});

// Load trip history
async function loadHistory() {
  const res = await api('/api/trips');
  const history = document.getElementById('history');
  history.innerHTML = '';
  if (res.trips && res.trips.length) {
    res.trips.forEach(t => {
      const div = document.createElement('div');
      div.className = 'trip';
      div.innerHTML = `<strong>Trip #${t.tripNumber}</strong> (${new Date(t.startTime).toLocaleString()} - ${new Date(t.endTime).toLocaleString()})<br/>
        Mode: ${t.mode} | Purpose: ${t.purpose} <br/>
        Origin: ${t.origin.lat.toFixed(5)}, ${t.origin.lng.toFixed(5)} | Destination: ${t.destination.lat.toFixed(5)}, ${t.destination.lng.toFixed(5)}<br/>
        Accompanying: ${t.accompanying && t.accompanying.length ? t.accompanying.map(a=>a.name).join(', ') : 'None'}
      `;
      history.appendChild(div);
    });
  } else {
    history.innerHTML = '<p class="muted">No trips recorded yet.</p>';
  }
}

// Initial
(async function(){
  // verify session; if not logged in redirect to index
  const me = await api('/api/auth/me');
  if (!me.user) {
    window.location.href = '/';
    return;
  }
  loadHistory();
})();
