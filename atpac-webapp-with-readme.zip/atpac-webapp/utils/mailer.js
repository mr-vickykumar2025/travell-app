const nodemailer = require('nodemailer');
const dotenv = require('dotenv');
dotenv.config();

module.exports = async function sendOtp(email, otp) {
  try {
    let transporter;
    let usingTestAccount = false;

    if (process.env.EMAIL_HOST && process.env.EMAIL_USER) {
      transporter = nodemailer.createTransport({
        host: process.env.EMAIL_HOST,
        port: process.env.EMAIL_PORT || 587,
        secure: process.env.EMAIL_SECURE === 'true',
        auth: {
          user: process.env.EMAIL_USER,
          pass: process.env.EMAIL_PASS,
        },
      });
    } else {
      // Create an Ethereal test account (for development)
      const testAccount = await nodemailer.createTestAccount();
      usingTestAccount = true;
      transporter = nodemailer.createTransport({
        host: 'smtp.ethereal.email',
        port: 587,
        auth: {
          user: testAccount.user,
          pass: testAccount.pass,
        },
      });
    }

    // ✅ Correct mail options
    const mailOptions = {
      from: process.env.EMAIL_FROM, // Your Gmail sender address
      to: email,                    // Use the function's email argument
      subject: "Your OTP for ATPAC App",
      text: `Your OTP is ${otp}. It expires in 5 minutes.`,
    };

    // ✅ Send the email
    const info = await transporter.sendMail(mailOptions);

    // Optional: preview URL for Ethereal
    const preview = usingTestAccount ? nodemailer.getTestMessageUrl(info) : null;

    return { messageId: info.messageId, preview };
  } catch (err) {
    console.error('Mailer error', err);
    return { error: err.message };
  }
};
