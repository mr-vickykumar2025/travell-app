const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const TravellerSchema = new Schema({
  name: String,
  age: Number,
  gender: String,
  relation: String
}, { _id: false });

const TripSchema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  tripNumber: Number,
  origin: { lat: Number, lng: Number, address: String },
  destination: { lat: Number, lng: Number, address: String },
  startTime: Date,
  endTime: Date,
  mode: String,
  purpose: String,
  accompanying: [TravellerSchema],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Trip', TripSchema);
